package com.zapper.zapperdisplaydata.commons;

public interface iRESTBase {
	
	public String getURL();
	public String getCookie();
	
	public void setCookie(String cookie);
	
}
